// false 
// var @name = "Anas";
// console.log(@name)

// var 2name = "Rocky";
// console.log(2name)

// var my name = "Ammar";
// console.log(my name)

// correct
// var name$ = "Muhammad";
// console.log(name$)

// var _na_me = "Rocky";
// console.log(_na_me)

// var name2 = "Rocky";
// console.log(name2)

// var name = "Anas";
// console.log(name)
// var age = 19;
// console.log(age)



function add(){
    var first =parseInt(document.getElementById("firstValue").value);
    var second =parseInt (document.getElementById("secondValue").value);
    var button = document.getElementById("btnOne");
if (button.value == "+" )
{
    var answer = first + second ;
    console.log(answer)
}
}

function sub(){
    var first =parseInt(document.getElementById("firstValue").value);
    var second =parseInt (document.getElementById("secondValue").value);
    var button = document.getElementById("btnTwo");
if (button.value == "-" )
{
    var answer = first - second ;
    console.log(answer)
}

}

function mul(){
    var first =parseInt(document.getElementById("firstValue").value);
    var second =parseInt (document.getElementById("secondValue").value);
    var button = document.getElementById("btnThree");
if (button.value == "*" )
{
    var answer = first * second ;
    console.log(answer)
}
// document.getElementById("answer").innerHTML.text = answer ;
}

function div(){
    var first =parseInt(document.getElementById("firstValue").value);
    var second =parseInt (document.getElementById("secondValue").value);
    var button = document.getElementById("btnFour");
if (button.value == "/" )
{
    var answer = first / second ;
    console.log(answer)
}
}